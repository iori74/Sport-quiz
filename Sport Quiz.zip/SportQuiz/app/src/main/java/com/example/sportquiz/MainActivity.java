package com.example.sportquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * the answerChoice method permit to do a choice per question
     * she also permit to know which answer is true or false
     */


    private String answerChoice() {
        CheckBox points2 = (CheckBox) findViewById(R.id.points2);
        boolean choice1 = points2.isChecked();
        CheckBox points1 = (CheckBox) findViewById(R.id.point1);
        boolean choice2 = points1.isChecked();
        CheckBox scoreEquality = (CheckBox) findViewById(R.id.scoreEquality);
        RadioButton yes = (RadioButton) findViewById(R.id.yes);
        boolean choice3 = yes.isChecked();
        RadioButton no = (RadioButton) findViewById(R.id.no);
        boolean choice4 = no.isChecked();
        boolean choice5 = scoreEquality.isChecked();
        CheckBox score = (CheckBox) findViewById(R.id.score);
        boolean choice6 = score.isChecked();

        EditText answer = (EditText) findViewById(R.id.answerQuestion);
        String choice7 = answer.toString();






        /** the instruction flux below evaluates the  errors who could be committed per the user
         * it also checks which are the good or bad answers
         */

        if ((choice1) & (choice2)  & (choice5) & (choice6) ) {
            Toast.makeText(getApplicationContext(), "Kindly choose one answer per question", Toast.LENGTH_SHORT).show();
            return "";
        }
        if ((choice1) & (choice2)) {
            Toast.makeText(getApplicationContext(), "Kindly enter  only one answer", Toast.LENGTH_SHORT).show();
            return "";
        }

        if ((choice5) & (choice6)) {
            Toast.makeText(getApplicationContext(), "Kindly enter only one answer", Toast.LENGTH_SHORT).show();
            return "";
        }
        if (choice7 =="pele "){
            Toast.makeText(getApplicationContext(), "Good job", Toast.LENGTH_SHORT).show();
        }
        if ((choice1) & (choice3)  & (choice5)  )  {
           if (choice7 =="pele "){
                Toast.makeText(getApplicationContext(), "Good job", Toast.LENGTH_SHORT).show();
           }
            Toast.makeText(getApplicationContext(), "Good job", Toast.LENGTH_SHORT).show();
            return "";
        }
        else{
            return " Begin again";
        }






    }

    public void submission(View view) {

        answerChoice();



    }





}